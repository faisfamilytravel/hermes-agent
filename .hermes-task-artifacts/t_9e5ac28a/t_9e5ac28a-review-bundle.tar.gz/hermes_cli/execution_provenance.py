"""Structured provenance and visibility for bounded cross-profile executions.

This is a same-user policy boundary, not hostile-process isolation. A process
running as the same OS user can alter its environment or the ledger. The
module provides fail-closed Hermes entry-point enforcement and an auditable
record, but does not claim cryptographic authority.
"""

from __future__ import annotations

import fcntl
import json
import os
import shlex
import sqlite3
import time
from pathlib import Path
from typing import Any

_REQUIRED_COMMANDER_FIELDS = {
    "authority_class", "authority_reference", "source", "target", "scope",
    "one_shot", "expires_at", "execution_id", "evidence", "terminal_condition",
}
_READ_ONLY_FORMS = {
    ("gateway", "status"), ("gateway", "health"), ("profile", "list"),
    ("kanban", "list"), ("kanban", "show"), ("kanban", "log"),
    ("kanban", "stats"), ("session", "list"), ("session", "search"),
}
_PROMPT_FLAGS = {"-q", "--query", "-z", "--prompt"}
_SENSITIVE_ARG_TERMS = {
    "authorization", "cookie", "credential", "credentials", "passphrase",
    "passwd", "password", "secret", "token",
}
_SENSITIVE_KEY_PREFIXES = {
    "access", "api", "auth", "authentication", "client", "encryption",
    "private", "secret", "signing", "webhook",
}
_EXACT_SENSITIVE_OPTIONS = {
    "--authority", "--body", "--content", "--message", "--system-prompt",
}


class ExecutionAuthorityError(RuntimeError):
    """Raised when a cross-profile execution lacks valid bounded authority."""


def _ledger_path() -> Path:
    return Path.home() / ".hermes" / "execution-provenance.jsonl"


def _command_words(argv: list[str]) -> list[str]:
    words: list[str] = []
    skip = False
    for arg in argv[1:]:
        if skip:
            skip = False
            continue
        if arg in {"-p", "--profile"}:
            skip = True
            continue
        if arg.startswith("--profile=") or arg.startswith("-"):
            continue
        words.append(arg)
    if words[:2] == ["-m", "hermes_cli.main"]:
        words = words[2:]
    return words


def is_read_only_invocation(argv: list[str]) -> bool:
    words = _command_words(argv)
    return len(words) >= 2 and tuple(words[:2]) in _READ_ONLY_FORMS


def is_agent_invocation(argv: list[str]) -> bool:
    if "chat" in argv[1:]:
        return True
    admin_commands = {
        "gateway", "profile", "kanban", "session", "logs", "config", "setup",
        "tools", "skills", "cron", "mcp", "version", "update", "uninstall",
        "dashboard", "desktop", "doctor", "models", "fallback", "completion",
    }
    return not any(arg in admin_commands for arg in argv[1:])


def _is_noninteractive(argv: list[str]) -> bool:
    return any(arg in _PROMPT_FLAGS or arg.startswith(("--query=", "--prompt="))
               for arg in argv[1:])


def _is_sensitive_option(arg: str) -> bool:
    """Return whether a long option name conventionally carries secret material."""
    if not arg.startswith("--"):
        return False
    option = arg.split("=", 1)[0]
    if option in _EXACT_SENSITIVE_OPTIONS:
        return True
    name = option[2:].lower().replace("_", "-")
    terms = [term for term in name.split("-") if term]
    if not terms:
        return False
    if terms[-1] in _SENSITIVE_ARG_TERMS:
        return True
    return terms[-1] == "key" and any(
        term in _SENSITIVE_KEY_PREFIXES for term in terms[:-1])


def _redacted_execution_path(argv: list[str]) -> str:
    safe = list(argv)
    redact_next = False
    for index, arg in enumerate(safe):
        if redact_next:
            safe[index] = "[REDACTED]"
            redact_next = False
            continue
        option, separator, _value = arg.partition("=")
        if option in _PROMPT_FLAGS or _is_sensitive_option(option):
            if separator:
                safe[index] = option + "=[REDACTED]"
            elif index + 1 < len(safe):
                redact_next = True
    return shlex.join(safe)


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except (ProcessLookupError, PermissionError, OSError):
        return False
    return True


def _load_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                rows.append(value)
    except OSError:
        return []
    return rows


def _append_row_once(path: Path, row: dict[str, Any], *, reject_replay: bool) -> None:
    """Append under an exclusive lock, atomically consuming one-shot IDs."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        if reject_replay:
            os.lseek(fd, 0, os.SEEK_SET)
            prior = os.read(fd, os.fstat(fd).st_size).decode("utf-8", errors="replace")
            execution_id = str(row.get("execution_id"))
            for line in prior.splitlines():
                try:
                    value = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(value, dict) and str(value.get("execution_id")) == execution_id:
                    raise ExecutionAuthorityError("one-shot execution ID already used")
        os.lseek(fd, 0, os.SEEK_END)
        os.write(fd, (json.dumps(row, sort_keys=True) + "\n").encode("utf-8"))
        os.fsync(fd)
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _validate_kanban_custody(*, source: str, target: str, task_id: str,
                             run_id: str, claim_lock: str, db_path: Path,
                             pid: int) -> None:
    if source != "mission-ctrl":
        raise ExecutionAuthorityError("Kanban custody requires Mission Control source")
    if not db_path.is_file():
        raise ExecutionAuthorityError("Kanban custody database is unavailable")
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        task = conn.execute(
            "SELECT assignee, status, claim_lock, claim_expires, current_run_id, worker_pid "
            "FROM tasks WHERE id = ?", (task_id,),
        ).fetchone()
        run = conn.execute(
            "SELECT task_id, profile, status, claim_lock, claim_expires, worker_pid "
            "FROM task_runs WHERE id = ?", (int(run_id),),
        ).fetchone()
        conn.close()
    except (OSError, sqlite3.Error, TypeError, ValueError) as exc:
        raise ExecutionAuthorityError("Kanban custody lookup failed closed") from exc
    now = time.time()
    valid = (
        task is not None and run is not None
        and task["assignee"] == target and run["profile"] == target
        and task["status"] == "running" and run["status"] == "running"
        and str(task["current_run_id"]) == str(run_id) and run["task_id"] == task_id
        and task["claim_lock"] == claim_lock and run["claim_lock"] == claim_lock
        and float(task["claim_expires"] or 0) > now
        and float(run["claim_expires"] or 0) > now
        and all(value in (None, pid) for value in (task["worker_pid"], run["worker_pid"]))
    )
    if not valid:
        raise ExecutionAuthorityError("Kanban custody does not match the active assigned run")


def authorize_profile_execution(*, source: str, target: str, argv: list[str],
                                authority_json: str | None,
                                ledger_path: Path | None = None,
                                kanban_task: str | None = None,
                                kanban_run: str | None = None,
                                kanban_claim_lock: str | None = None,
                                kanban_db_path: Path | None = None,
                                pid: int | None = None) -> dict[str, Any] | None:
    """Authorize and record a cross-profile agent execution."""
    source = str(source or "").strip()
    target = str(target or "").strip()
    if (not source or not target or source == target or not is_agent_invocation(argv)
            or is_read_only_invocation(argv)):
        return None
    if source == "external" and not _is_noninteractive(argv):
        return None

    path = ledger_path or _ledger_path()
    now = time.time()
    if kanban_task and kanban_run and kanban_claim_lock:
        db_path = kanban_db_path or Path(
            os.environ.get("HERMES_KANBAN_DB") or Path.home() / ".hermes" / "kanban.db")
        _validate_kanban_custody(
            source=source, target=target, task_id=kanban_task, run_id=kanban_run,
            claim_lock=kanban_claim_lock, db_path=db_path, pid=int(pid or os.getpid()))
        record: dict[str, Any] = {
            "authority_class": "mission_control_kanban",
            "authority_reference": f"kanban:{kanban_task}:run:{kanban_run}",
            "source": source, "target": target,
            "scope": f"assigned Kanban task {kanban_task}", "one_shot": True,
            "expires_at": None, "execution_id": f"kanban-{kanban_task}-run-{kanban_run}",
            "evidence": f"kanban:{kanban_task}",
            "terminal_condition": "Kanban terminal action or worker exit",
        }
    else:
        if not authority_json:
            raise ExecutionAuthorityError(
                f"cross-profile execution {source}->{target} requires structured authority")
        try:
            parsed = json.loads(authority_json)
        except json.JSONDecodeError as exc:
            raise ExecutionAuthorityError("structured authority is not valid JSON") from exc
        if not isinstance(parsed, dict):
            raise ExecutionAuthorityError("structured authority must be a JSON object")
        missing = sorted(_REQUIRED_COMMANDER_FIELDS - parsed.keys())
        if missing:
            raise ExecutionAuthorityError(f"structured authority missing: {', '.join(missing)}")
        record = dict(parsed)
        for field in _REQUIRED_COMMANDER_FIELDS - {"one_shot", "expires_at"}:
            if not str(record[field]).strip():
                raise ExecutionAuthorityError(f"authority field {field} must not be empty")
        if record["authority_class"] != "commander_direct":
            raise ExecutionAuthorityError("authority class must be commander_direct")
        if record["source"] != source:
            raise ExecutionAuthorityError("authority source mismatch")
        if record["target"] != target:
            raise ExecutionAuthorityError("authority target mismatch")
        if record["one_shot"] is not True:
            raise ExecutionAuthorityError("direct Commander exception must be one-shot")
        try:
            expires_at = float(record["expires_at"])
        except (TypeError, ValueError) as exc:
            raise ExecutionAuthorityError("authority expiry must be a Unix timestamp") from exc
        if expires_at <= now:
            raise ExecutionAuthorityError("structured authority expired")

    record.update({
        "execution_path": _redacted_execution_path(argv),
        "kanban_tracked": bool(kanban_task and kanban_run),
        "pid": int(pid or os.getpid()), "started_at": now, "state": "running",
    })
    _append_row_once(path, record,
                     reject_replay=record.get("authority_class") == "commander_direct")
    return record


def list_execution_status(*, ledger_path: Path | None = None) -> list[dict[str, Any]]:
    rows = _load_rows(ledger_path or _ledger_path())
    for row in rows:
        if row.get("state") == "running" and not _pid_alive(int(row.get("pid") or 0)):
            row["state"] = "terminal"
    return sorted(rows, key=lambda row: float(row.get("started_at") or 0), reverse=True)


def format_execution_status(*, ledger_path: Path | None = None,
                            limit: int = 10) -> list[str]:
    lines: list[str] = []
    for row in list_execution_status(ledger_path=ledger_path)[:limit]:
        tracked = "yes" if row.get("kanban_tracked") else "no"
        lines.append(
            "Execution "
            f"{row.get('execution_id', 'unknown')}: source={row.get('source', 'unknown')} "
            f"authority={row.get('authority_class', 'unknown')}/"
            f"{row.get('authority_reference', 'unknown')} target={row.get('target', 'unknown')} "
            f"path={row.get('execution_path', 'unknown')} kanban={tracked} "
            f"scope={row.get('scope', 'unknown')} one_shot={row.get('one_shot', 'unknown')} "
            f"expires={row.get('expires_at', 'none')} evidence={row.get('evidence', 'unknown')} "
            f"terminal={row.get('terminal_condition', 'unknown')} state={row.get('state', 'unknown')}")
    return lines
