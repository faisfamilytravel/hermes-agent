"""Tests for bounded cross-profile execution provenance."""

from __future__ import annotations

import json
import os
import shlex
import sqlite3
import threading
import time
from pathlib import Path

import pytest

from hermes_cli.execution_provenance import (
    ExecutionAuthorityError,
    _redacted_execution_path,
    authorize_profile_execution,
    list_execution_status,
)


def _authority(**overrides):
    data = {
        "authority_class": "commander_direct",
        "authority_reference": "DEC-TEST-001",
        "source": "csm",
        "target": "s6",
        "scope": "one bounded test",
        "one_shot": True,
        "expires_at": time.time() + 300,
        "execution_id": "exec-test-001",
        "evidence": "kanban:t_test",
        "terminal_condition": "process exits",
    }
    data.update(overrides)
    return data


def _kanban_db(path: Path, *, assignee="s6", run_id=9, claim="claim-1"):
    conn = sqlite3.connect(path)
    conn.executescript("""
        CREATE TABLE tasks (id TEXT PRIMARY KEY, assignee TEXT, status TEXT,
            claim_lock TEXT, claim_expires INTEGER, current_run_id INTEGER,
            worker_pid INTEGER);
        CREATE TABLE task_runs (id INTEGER PRIMARY KEY, task_id TEXT,
            profile TEXT, status TEXT, claim_lock TEXT, claim_expires INTEGER,
            worker_pid INTEGER);
    """)
    expiry = int(time.time()) + 300
    conn.execute("INSERT INTO tasks VALUES (?, ?, 'running', ?, ?, ?, NULL)",
                 ("t_1", assignee, claim, expiry, run_id))
    conn.execute("INSERT INTO task_runs VALUES (?, 't_1', ?, 'running', ?, ?, NULL)",
                 (run_id, assignee, claim, expiry))
    conn.commit()
    conn.close()
    return path


def test_exact_commander_exception_is_recorded(tmp_path):
    ledger = tmp_path / "executions.jsonl"
    record = authorize_profile_execution(
        source="csm", target="s6",
        argv=["hermes", "-p", "s6", "chat", "-q", "work"],
        authority_json=json.dumps(_authority()), ledger_path=ledger, pid=os.getpid(),
    )
    assert record["authority_class"] == "commander_direct"
    assert record["authority_reference"] == "DEC-TEST-001"
    assert record["source"] == "csm"
    assert record["target"] == "s6"
    assert record["execution_path"] == "hermes -p s6 chat -q '[REDACTED]'"
    assert record["kanban_tracked"] is False
    assert record["state"] == "running"
    assert list_execution_status(ledger_path=ledger)[0]["execution_id"] == "exec-test-001"


def test_independent_cross_profile_chat_is_rejected(tmp_path):
    with pytest.raises(ExecutionAuthorityError, match="structured authority"):
        authorize_profile_execution(
            source="csm", target="s6",
            argv=["python", "-m", "hermes_cli.main", "chat"],
            authority_json=None, ledger_path=tmp_path / "executions.jsonl",
        )


def test_mismatched_expired_and_replayed_authority_are_rejected(tmp_path):
    ledger = tmp_path / "executions.jsonl"
    with pytest.raises(ExecutionAuthorityError, match="target mismatch"):
        authorize_profile_execution(source="csm", target="s7", argv=["hermes", "chat"],
            authority_json=json.dumps(_authority()), ledger_path=ledger)
    with pytest.raises(ExecutionAuthorityError, match="expired"):
        authorize_profile_execution(source="csm", target="s6", argv=["hermes", "chat"],
            authority_json=json.dumps(_authority(expires_at=time.time() - 1)), ledger_path=ledger)
    payload = json.dumps(_authority())
    authorize_profile_execution(source="csm", target="s6", argv=["hermes", "chat"],
        authority_json=payload, ledger_path=ledger)
    with pytest.raises(ExecutionAuthorityError, match="already used"):
        authorize_profile_execution(source="csm", target="s6", argv=["hermes", "chat"],
            authority_json=payload, ledger_path=ledger)


def test_kanban_dispatch_is_allowed_and_visible(tmp_path):
    ledger = tmp_path / "executions.jsonl"
    record = authorize_profile_execution(
        source="mission-ctrl", target="s6",
        argv=["hermes", "-p", "s6", "chat", "-q", "work kanban task t_1"],
        authority_json=None, ledger_path=ledger, kanban_task="t_1",
        kanban_run="9", kanban_claim_lock="claim-1",
        kanban_db_path=_kanban_db(tmp_path / "kanban.db"),
    )
    assert record["authority_class"] == "mission_control_kanban"
    assert record["authority_reference"] == "kanban:t_1:run:9"
    assert record["kanban_tracked"] is True


@pytest.mark.parametrize("source,target,run,claim", [
    ("csm", "s6", "9", "claim-1"),
    ("mission-ctrl", "s7", "9", "claim-1"),
    ("mission-ctrl", "s6", "8", "claim-1"),
    ("mission-ctrl", "s6", "9", "wrong"),
])
def test_forged_or_inherited_kanban_custody_is_rejected(tmp_path, source, target, run, claim):
    with pytest.raises(ExecutionAuthorityError):
        authorize_profile_execution(
            source=source, target=target,
            argv=["hermes", "-p", target, "chat", "-q", "work"],
            authority_json=None, ledger_path=tmp_path / "ledger.jsonl",
            kanban_task="t_1", kanban_run=run, kanban_claim_lock=claim,
            kanban_db_path=_kanban_db(tmp_path / "kanban.db"),
        )


def test_missing_kanban_database_fails_closed(tmp_path):
    with pytest.raises(ExecutionAuthorityError, match="Kanban custody"):
        authorize_profile_execution(
            source="mission-ctrl", target="s6", argv=["hermes", "-p", "s6", "chat", "-q", "work"],
            authority_json=None, ledger_path=tmp_path / "ledger.jsonl",
            kanban_task="t_1", kanban_run="9", kanban_claim_lock="claim-1",
            kanban_db_path=tmp_path / "missing.db",
        )


def test_external_noninteractive_rejects_but_human_interactive_is_intentional(tmp_path):
    with pytest.raises(ExecutionAuthorityError, match="structured authority"):
        authorize_profile_execution(
            source="external", target="s6",
            argv=["hermes", "-p", "s6", "chat", "-q", "secret prompt"],
            authority_json=None, ledger_path=tmp_path / "ledger.jsonl")
    assert authorize_profile_execution(
        source="external", target="s6", argv=["hermes", "-p", "s6"],
        authority_json=None, ledger_path=tmp_path / "ledger.jsonl") is None


def test_commander_execution_id_is_consumed_atomically(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    payload = json.dumps(_authority())
    barrier = threading.Barrier(16)
    accepted = []

    def attempt():
        barrier.wait()
        try:
            authorize_profile_execution(source="csm", target="s6", argv=["hermes", "chat"],
                authority_json=payload, ledger_path=ledger)
            accepted.append(True)
        except ExecutionAuthorityError:
            pass

    threads = [threading.Thread(target=attempt) for _ in range(16)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert len(accepted) == 1
    assert sum(json.loads(line)["execution_id"] == "exec-test-001"
               for line in ledger.read_text().splitlines()) == 1


def test_prompt_payload_is_redacted_from_ledger(tmp_path):
    ledger = tmp_path / "ledger.jsonl"
    record = authorize_profile_execution(
        source="csm", target="s6",
        argv=["hermes", "-p", "s6", "chat", "-q", "TOP SECRET BODY"],
        authority_json=json.dumps(_authority()), ledger_path=ledger)
    assert "TOP SECRET BODY" not in record["execution_path"]
    assert "[REDACTED]" in record["execution_path"]
    assert "TOP SECRET BODY" not in ledger.read_text()


@pytest.mark.parametrize(("argv", "secret"), [
    (["hermes", "chat", "--api-key", "sk-live"], "sk-live"),
    (["hermes", "chat", "--access_token=opaque-token"], "opaque-token"),
    (["hermes", "chat", "--client-secret", "oauth-secret"], "oauth-secret"),
    (["hermes", "chat", "--password=hunter2"], "hunter2"),
    (["hermes", "chat", "--authorization", "Bearer abc123"], "Bearer abc123"),
    (["hermes", "chat", "--cookie=session=private"], "session=private"),
    (["hermes", "chat", "--signing_key", "private-material"], "private-material"),
    (["hermes", "chat", "--webhook-token=hook-secret"], "hook-secret"),
])
def test_sensitive_named_arguments_are_redacted_generically(argv, secret):
    execution_path = _redacted_execution_path(argv)
    assert secret not in execution_path
    assert "[REDACTED]" in execution_path


@pytest.mark.parametrize(
    "option",
    ["--body", "--message", "--content", "--authority", "--system-prompt"],
)
@pytest.mark.parametrize("form", ["separate", "equals"])
def test_explicit_sensitive_options_are_redacted_in_both_forms(option, form):
    secret = f"SENTINEL-{option[2:].upper()}-SECRET"
    argv = (
        ["hermes", "chat", option, secret]
        if form == "separate"
        else ["hermes", "chat", f"{option}={secret}"]
    )

    execution_path = _redacted_execution_path(argv)

    assert secret not in execution_path
    assert "[REDACTED]" in execution_path


def test_non_sensitive_lookalike_arguments_remain_visible():
    argv = [
        "hermes", "chat", "--token-count", "4096", "--password-policy", "strict",
        "--secret-santa", "enabled", "--cookie-file-count", "2",
        "--body-format", "markdown", "--message-count", "3",
        "--content-type", "application/json", "--authority-level", "staff",
        "--system-prompt-mode", "inherit",
    ]
    execution_path = _redacted_execution_path(argv)
    assert "[REDACTED]" not in execution_path
    assert execution_path == shlex.join(argv)


def test_default_ledger_is_shared_across_profile_home_overlay(monkeypatch, tmp_path):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setenv("HERMES_HOME", str(tmp_path / ".hermes" / "profiles" / "s6"))
    from hermes_cli.execution_provenance import _ledger_path
    assert _ledger_path() == tmp_path / ".hermes" / "execution-provenance.jsonl"


def test_same_profile_and_read_only_inspection_need_no_authority(tmp_path):
    ledger = tmp_path / "executions.jsonl"
    assert authorize_profile_execution(source="csm", target="csm", argv=["hermes", "chat"],
        authority_json=None, ledger_path=ledger) is None
    assert authorize_profile_execution(source="csm", target="s6",
        argv=["hermes", "-p", "s6", "gateway", "status"],
        authority_json=None, ledger_path=ledger) is None
    assert not ledger.exists()


def test_untracked_process_visibility_and_terminal_state(tmp_path):
    ledger = tmp_path / "executions.jsonl"
    ledger.write_text(json.dumps({
        **_authority(execution_id="exec-dead"),
        "execution_path": "HERMES_HOME=/tmp/s6 python -m hermes_cli.main chat",
        "kanban_tracked": False, "pid": 99999999,
        "started_at": time.time() - 10, "state": "running",
    }) + "\n", encoding="utf-8")
    row = list_execution_status(ledger_path=ledger)[0]
    assert row["kanban_tracked"] is False
    assert row["state"] == "terminal"
